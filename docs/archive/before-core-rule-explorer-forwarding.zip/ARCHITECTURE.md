# Folder Explorer — architecture & IPC contract

Folder Explorer replaces the Windows desktop icon layer with its own window so that
icons can be merged into phone-style (iOS/Android) folders.

* `src-tauri/` — Rust. Owns everything Win32: the desktop-level window, hiding the
  Windows icon view, enumerating desktop items, icons, shell menus, file operations,
  wallpaper, persistence on disk, tray, global hotkey, extra windows.
* `src/` — React + TypeScript + Motion. Owns all UI and **all layout logic**
  (grid placement, folders, undo/redo, reconciliation with the item list).
  The backend stores the layout and settings as opaque JSON.

UI language: Turkish. All UI strings live in `src/i18n.ts`.

## Windows

| label      | url                         | notes |
|------------|-----------------------------|-------|
| `desktop`  | `index.html?view=desktop`   | Created by Rust at startup. Covers the bounding box of all monitors (physical px). No decorations, **transparent** (the real wallpaper — incl. slideshows and Wallpaper Engine — shows through), `WS_EX_TOOLWINDOW`, kept directly above the shell desktop (Progman) in z-order. The UI only paints a wallpaper when the user picks a custom one (image/colour/gradient). |
| `search`   | `index.html?view=search`    | Created lazily. Frameless, transparent + acrylic, always-on-top, skip taskbar, ~680x480 logical, centered on the monitor under the cursor. Hidden (not closed) when dismissed. |
| `settings` | `index.html?view=settings`  | Created lazily. Normal decorated window ~1000x700 logical, mica. Closing it destroys it. |

### Desktop window z-order rules (Rust)
* Always anchored **directly above Progman** (`WM_WINDOWPOSCHANGING` forces `hwndInsertAfter`
  to the window right above Progman, or `HWND_TOP` when Progman is on top / that window is
  topmost). Normally Progman is at the bottom, so we are too — even when activated.
* A guard thread (`fe-zguard`, every 40 ms) fixes both directions of drift (`ensure_z`): Progman
  above us (Win+D / "Show desktop" lifts it) and a visible, non-minimized window between us and
  Progman (we drifted over app windows). It also re-shows us if we were hidden or minimized. In
  traces this puts the window back ~20 ms after Progman is raised, so the icons never blink.
* The window is excluded from Aero Peek (`DWMWA_EXCLUDED_FROM_PEEK`) and kept 6 px short of the
  monitors' right/bottom edge (`FIT_INSET`).
* Wallpaper Engine pauses for fullscreen / maximized windows by user setting; with nothing
  maximized it keeps playing with our window present.
* `raise_desktop(true)` enters raised mode on demand until another window becomes foreground (a
  1.5 s grace period after the raise ignores the foreground churn when a menu closes). The UI
  raises whenever a folder panel or settings dialog opens (any way: click, group right-click, tray,
  "Yeni ▸ Grup", search) and lowers again when the last one closes.
* Non-client area is suppressed (`WM_NCCALCSIZE`/`WM_NCPAINT`/`WM_NCACTIVATE`), otherwise
  Windows paints a caption into the transparent window on activation.
* Never minimizable (strip `WS_MINIMIZEBOX`, ignore `SC_MINIMIZE`).
* `SetPropW(hwnd, "NonRudeHWND", 1)` so the taskbar does not treat it as a fullscreen app.

### Hiding the Windows icons
* `SysListView32` inside `SHELLDLL_DefView` gets `ShowWindow(SW_HIDE)` (non-persistent:
  an Explorer restart/reboot always brings icons back). Re-checked every 2 s and after
  `TaskbarCreated` (Explorer restart).
* Restored on quit, panic, console Ctrl+C, `WM_ENDSESSION`, and by a watchdog: the app
  spawns itself as `folder-explorer.exe --watchdog <pid>`; that process waits for the
  parent to exit and then shows the icons again. `main()` handles `--watchdog` before Tauri starts.
* Before hiding for the first time, the current Windows icon positions are captured via
  `IShellWindows::FindWindowSW(CSIDL_DESKTOP)` → `IFolderView::GetItemPosition` (+ `GetSpacing`).

## Coordinates
All rects coming from Rust are **physical screen pixels**. The frontend converts with
`css = (screen - windowOrigin) / scaleFactor`, where `windowOrigin` and `scaleFactor`
come from `get_environment`. (Mixed-DPI multi-monitor setups are approximated with
the window's scale factor.)

## Types (TS ⇄ Rust, camelCase JSON)

```ts
type Rect = { x: number; y: number; width: number; height: number };

type MonitorInfo = {
  id: string;            // device name, e.g. "\\\\.\\DISPLAY1"
  primary: boolean;
  bounds: Rect;          // physical, screen coords
  work: Rect;            // physical, screen coords (excludes taskbar)
  scale: number;         // monitor DPI / 96
};

type Environment = {
  monitors: MonitorInfo[];
  windowOrigin: { x: number; y: number }; // physical screen pos of desktop window client (0,0)
  scaleFactor: number;                     // desktop window scale factor
  desktopDir: string;
  publicDesktopDir: string;
  isDev: boolean;
};

type DesktopItem = {
  id: string;            // files: full path lowercased; system items: "::{clsid}" lowercased
  kind: "file" | "folder" | "system";   // folder = real directory on disk
  path: string;          // full path (original case) or "::{CLSID}"
  parsingName: string;   // what SHCreateItemFromParsingName accepts (== path for files)
  name: string;          // shell display name (SHGetFileInfo SHGFI_DISPLAYNAME)
  ext: string;           // lowercase ".lnk", ".txt", "" for dirs/system
  isShortcut: boolean;   // .lnk / .url
  isPublic: boolean;     // lives in the Public desktop
  modified: number;      // ms since epoch (0 for system)
  size: number;          // bytes (0 for dirs/system)
  iconVersion: string;   // changes when the icon may have changed (e.g. mtime)
  recycleFull?: boolean; // only for the Recycle Bin item
};

type WindowsLayout = {
  spacing: { x: number; y: number } | null;   // physical px, IFolderView::GetSpacing
  items: { id: string; x: number; y: number }[]; // physical screen coords of icon top-left
};

type WallpaperInfo = {
  monitorId: string;
  path: string | null;   // image path, null when solid colour
  position: "fill" | "fit" | "stretch" | "tile" | "center" | "span";
  color: string;         // "#rrggbb" background colour
  version: string;       // changes when the wallpaper changes
};

type StartApp = { name: string; parsingName: string /* "shell:AppsFolder\\<AUMID>" */ };

type PersistedState = { layout: unknown | null; settings: unknown | null };
type BackupInfo = { name: string; createdAt: number; size: number };
```

## Commands (`invoke(name, args)`; args camelCase)

| command | args | returns | notes |
|---|---|---|---|
| `get_environment` | – | `Environment` | |
| `list_desktop_items` | – | `DesktopItem[]` | user desktop + public desktop (skip hidden/system files and `desktop.ini`) + visible system icons (Recycle Bin, This PC, User files, Network, Control Panel per `HideDesktopIcons\NewStartPanel`) |
| `get_windows_layout` | – | `WindowsLayout` | snapshot captured at startup before hiding icons |
| `open_item` | `{ path }` | `()` | `ShellExecuteExW` "open"; system items via `explorer.exe shell:::{CLSID}` |
| `show_shell_menu` | `{ paths: string[] }` | `string \| null` | native IContextMenu at cursor (IContextMenu2/3 messages forwarded). If the user picks **rename** or **delete**, the verb is NOT invoked; returns `"rename"`/`"delete"` so the UI handles it (undoable). Otherwise invokes and returns the verb or `null`. |
| `forward_context_menu` | – | `()` | right-click on an empty spot: clears Explorer's (hidden) selection and posts `WM_CONTEXTMENU` to Explorer's desktop view at the cursor, so **Windows' own menu** opens exactly as on a normal desktop. Explorer's desktop is made the foreground window first (as a real click would), otherwise the menu has no active owner and stays open when the user switches to another window; activating it raises it over the app windows, so it is sent back to the bottom right away (it stays active). Nothing in Windows is modified (no registry, no shell extensions). Menu lifetime is managed like on Windows' own desktop: an open menu is closed first (`dismiss_menu`: `WM_CANCELMODE` for the classic menu, deactivation for the XAML one, otherwise the new `WM_CONTEXTMENU` would queue behind it and pop up later), and a `fe-menukeeper` thread watches Explorer's UI thread (`GetGUIThreadInfo`: menu mode / active XAML host) and hands the foreground to Explorer whenever a menu appears — a menu only closes on an outside click while Explorer owns the foreground, which it does not after "Daha fazla seçenek göster" — and back to us when the menu is gone. |
| `forward_item_menu` | `{ ids: string[] }` | `()` | right-click on real desktop items (files, folders, system icons); `ids[0]` is the clicked one. Selects them in Explorer's hidden desktop view (matching by parsing name, `IShellView::SelectItem`), shifts the hidden icon-list *window* so the clicked item lies under the cursor (Windows picks item vs. background menu by what is under the cursor; no icon is moved inside Explorer's list), and shows that window fully transparent (layered alpha 0) while the menu opens — Explorer builds the item menu only for a *visible* list. Window position and visibility are put back ~0.9 s later and on exit. Then posts `WM_CONTEXTMENU`, so **Windows' own item menu** opens at the cursor. Errors if nothing matched; the UI then only shows a toast. |
| `explorer_rename_active` | – | `boolean` | Explorer started an in-place rename in its hidden view (menu ▸ Rename); the UI polls this after an item menu (and after "Yeni ▸ Klasör"), cancels it, takes the foreground back and shows our own name box |
| `focus_desktop` | – | `()` | gives our window the keyboard without raising it (Alt-tap + `SetForegroundWindow`), used before our name box opens |
| `cancel_explorer_rename` | – | `()` | cancels the in-place rename Explorer starts in its hidden icon view after "Yeni ▸ Klasör"; our own name box takes over |
| `show_new_menu` | – | `boolean` | native Windows "New ▸" menu (CLSID_NewMenu) for the desktop folder, at cursor. `true` if something was created. |
| `recycle` | `{ paths }` | `()` | IFileOperation + FOFX_RECYCLEONDELETE / FOF_ALLOWUNDO |
| `restore_from_recycle` | `{ paths }` | `string[]` | restores the most recently deleted entries with these original paths ("undelete" verb); returns restored paths |
| `rename_item` | `{ path, newName }` | `string` (new path) | `newName` is a display name; keeps a hidden extension (.lnk, known types) |
| `move_into_folder` | `{ paths, targetDir }` | `()` | real move via IFileOperation (shows Windows conflict UI) |
| `import_dropped` | `{ paths, copy?: boolean }` | `string[]` | copy/move external files into the user desktop (default like Explorer: same drive moves, other drive copies; name collisions get a new name); returns the real new paths. Files already on a desktop are returned unchanged. |
| `start_drag_out` | `{ paths }` | `string` | native OLE drag (`SHDoDragDrop`), call while the mouse button is down; returns `"copy" \| "move" \| "link" \| "none"` |
| `cursor_over_foreign_window` | – | `boolean` | true when the top-level window under the cursor is not the desktop window (another app, taskbar…) |
| `list_start_apps` | – | `StartApp[]` | enumerate `FOLDERID_AppsFolder` |
| `create_shortcut` | `{ parsingName, name }` | `string` (path) | `.lnk` on the user desktop via IShellLinkW::SetIDList |
| `create_url_shortcut` | `{ url, name }` | `string` | `.url` file on the user desktop |
| `get_wallpapers` | – | `WallpaperInfo[]` | IDesktopWallpaper |
| `load_state` | – | `PersistedState` | `%APPDATA%\Folder Explorer\state.json` |
| `save_layout` | `{ layout }` | `()` | atomic write (temp + rename), debounced by the UI |
| `save_settings` | `{ settings }` | `()` | persists, emits `settings-changed` to all windows, re-registers the search hotkey from `settings.behavior.searchHotkey`, applies `settings.behavior.lockLayout` to the tray check item |
| `list_backups` / `restore_backup` | `{ name }` | `BackupInfo[]` / `PersistedState` | backups in `…\backups\`, keep 10; one on startup and at most every 15 min while changed |
| `export_state` / `import_state` | `{ path }` | `()` / `PersistedState` | |
| `import_media` | `{ path, kind: "icon" \| "wallpaper" }` | `string` | copies into `…\media\`, returns stored path |
| `open_settings_window` | – | `()` | |
| `show_search` | `{ initial?: string }` | `()` | show/focus search window, emits `search-open { initial }` to it |
| `take_search_initial` | – | `string` | the search window calls it on mount (first `search-open` may fire before it listens) |
| `hide_search` | – | `()` | |
| `raise_desktop` | `{ raised: boolean }` | `()` | |
| `set_windows_icons_mode` | `{ enabled: boolean }` | `()` | true = hide our desktop window and show the Windows icons again (tray toggle) |
| `quit_app` | – | `()` | restores icons, exits |

## Custom protocol `fe`
Served via `register_asynchronous_uri_scheme_protocol("fe", …)`. From JS use
`convertFileSrc("<route>", "fe")` → `http://fe.localhost/<route>` and append a query string.

* `fe://icon?p=<parsingName>&s=<px>&v=<version>` → PNG (IShellItemImageFactory, thumbnails allowed,
  rendered on a dedicated STA worker thread, cached in memory by (p,s,v)). `s` is physical px.
* `fe://wallpaper?m=<monitorId>&v=<version>` → the Windows wallpaper image bytes for that monitor.
* `fe://media?p=<path>` → files inside `%APPDATA%\Folder Explorer\media\` only.

## Events (Rust → JS)

| event | payload | |
|---|---|---|
| `desktop-changed` | `{ renames: { from: string; to: string }[] }` | debounced (~250 ms) file-system change on either desktop folder; ids in renames are lowercased paths. UI re-fetches `list_desktop_items`. |
| `environment-changed` | – | monitors / DPI / work area changed |
| `wallpaper-changed` | – | |
| `settings-changed` | `{ settings }` | |
| `desktop-raised` | `{ raised: boolean }` | |
| `search-open` | `{ initial: string }` | to the search window |
| `open-virtual-folder` | `{ folderId: string }` | from search to the desktop window (desktop also gets raised) |
| `new-group` | – | "Yeni ▸ Grup" was picked in the Windows menu |
| `tray-action` | `{ action: "toggle-lock" \| "add-app" \| "new-group" }` | `add-app` / `new-group` also raise the desktop window |

File drops from Explorer use Tauri's own `onDragDropEvent` on the desktop webview.

## Persisted JSON (owned by the UI)

```ts
type Placement = { m: string; p: number; c: number; r: number }; // monitor, page, col, row
type FolderLook = { opacity?: number; blur?: number; radius?: number; preview?: 2 | 3; icon?: string;
                   panelStyle?: "ios" | "android"; panelOpacity?: number }; // unset = global setting
type Layout = {
  version: 1;
  folders: Record<string, { id: string; name: string; color: string | null; children: string[]; look?: FolderLook }>;
  placements: Record<string, Placement>;   // top-level desktop items (files, system items, virtual folders)
  custom: Record<string, { name?: string; icon?: string }>;
  remembered: Record<string, { at: number; placement?: Placement; folder?: string; index?: number }>;
  home: Record<string, { placement: Placement; at: number }>;
  importedFromWindows: boolean;
};
```
`home` protects the layout from temporary screen changes (a game switching resolution, a
monitor turning off, DPI / taskbar changes): when an item's cell no longer exists, `reconcile`
shows it in the nearest free cell but keeps its real cell in `home`, and moves it back as soon as
that cell exists again and is free. A user action that moves the item (`commit` → `forgetHomes`)
or puts it in a folder drops the entry; entries expire after 30 days.
Virtual folder ids start with `v:`. Every item is either in `placements` or in exactly one
folder's `children`.

## Notes
* Each window also gets `window.__FE_VIEW__` via an initialization script, in case the query
  string is lost.
* Tauri's native drag-drop handler is on (for files from Explorer), so HTML5 drag & drop does
  not work inside the webview; all icon dragging is pointer-event based (`src/desktop/dnd.ts`).
* When the app is started from an MSIX-packaged parent (e.g. a sandboxed terminal), `%APPDATA%`
  may be virtualized; the state then lives under that package's `LocalCache\Roaming`.

## Command-line flags (`folder-explorer.exe`)
| flag | what it does |
|---|---|
| `--quit` | posts a private message to a running instance's desktop window, which quits gracefully (restoring the Windows icons); waits for the process to exit. Used by the installer hooks. |
| `--new-group` | "Yeni ▸ Grup" in the Windows menu: posts to the running desktop, which creates a group where the user right-clicked (starts the app if it is not running). |
| `--item-select-test` | diagnostics: selects sample items in Explorer's hidden desktop view (file, folder, public item, Recycle Bin, three at once) and clears the selection; opens no menu. |
| `--newmenu-test` | diagnostics: register → dump → unregister the "Yeni ▸ Grup" entry (use from a sandboxed shell only). |
| `--newmenu-dump` | diagnostics: prints the entries of Windows' "New" list for the desktop (no UI). |
| `--show-icons` | makes the Windows desktop icons visible again and exits (safety net). |
| `--watchdog <pid>` | internal: waits for `<pid>` to exit, then shows the Windows icons. |
| `--autostart` | passed by the "start with Windows" entry; a second instance launched with it stays silent. |
| `--selftest [dir]` | diagnostics without UI (monitors, items, Windows icon layout per column, wallpapers, an icon PNG). |

## Installer
`npm run tauri build` → `src-tauri/target/release/bundle/nsis/Folder Explorer_<ver>_x64-setup.exe`
(per-user install, Turkish UI). `src-tauri/installer-hooks.nsh` runs `--quit` before installing
over / uninstalling a running copy, `--show-icons` on uninstall, and removes the
"start with Windows" registry values. The only change to Windows' own shell is the standard per-user "Yeni ▸ Grup" entry
(`HKCU\Software\Classes\.fegroup\ShellNew` with `Command` → `folder-explorer.exe --new-group`, plus the
`FolderExplorer.Group` ProgID). The app manages it itself (`shell_new.rs`): at startup and on every settings
save it makes the registry match `behavior.newMenuEntry` (default on; Ayarlar ▸ Davranış) — writing it (with
the current exe path, so it also works when run from source) or deleting exactly those two keys — and sends
`SHCNE_ASSOCCHANGED` only when something changed. The installer writes/removes the same keys. Explorer's
New-menu cache is never touched. `--newmenu-dump` lists the New menu in-process; `--newmenu-test` registers,
dumps, unregisters (13 entries without ours, 14 with).
Explorer cache changes).

## Context menus
The app has **no context menus of its own**. Right-click on an empty spot or on a real item opens
Windows' own menu (above). A group (virtual folder) has no Windows menu, so right-click opens its
settings window (name, colour, look, "Grubu dağıt", "İçindekilerle birlikte sil"). Ctrl+E opens the
same window for the selected icon (custom name / icon for files). Right-click inside an open group
panel does nothing.
