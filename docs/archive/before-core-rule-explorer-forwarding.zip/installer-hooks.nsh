; Folder Explorer — NSIS installer hooks (see tauri.conf.json > bundle.windows.nsis.installerHooks)
;
; The app hides the Windows desktop icons while it runs. If an installer simply killed it,
; the icons could stay hidden, so every hook first asks a running copy to close gracefully
; (`--quit`), which brings the icons back.
;
; Windows' own shell is touched in exactly one way: the standard per-user "Yeni ▸ Grup" entry
; (two keys under HKCU\Software\Classes: .fegroup and FolderExplorer.Group). Nothing else is
; written or deleted — in particular never Explorer's New-menu cache.

!macro NSIS_HOOK_PREINSTALL
  ; Upgrading over a running copy.
  IfFileExists "$INSTDIR\${MAINBINARYNAME}.exe" 0 +2
    ExecWait '"$INSTDIR\${MAINBINARYNAME}.exe" --quit'
!macroend

!macro NSIS_HOOK_POSTINSTALL
  WriteRegStr HKCU "Software\Classes\.fegroup" "" "FolderExplorer.Group"
  WriteRegStr HKCU "Software\Classes\.fegroup\ShellNew" "Command" '"$INSTDIR\${MAINBINARYNAME}.exe" --new-group'
  WriteRegStr HKCU "Software\Classes\.fegroup\ShellNew" "MenuText" "Grup"
  WriteRegStr HKCU "Software\Classes\.fegroup\ShellNew" "IconPath" '$INSTDIR\${MAINBINARYNAME}.exe,0'
  WriteRegStr HKCU "Software\Classes\FolderExplorer.Group" "" "Grup"
  WriteRegStr HKCU "Software\Classes\FolderExplorer.Group\DefaultIcon" "" '$INSTDIR\${MAINBINARYNAME}.exe,0'
  ; SHCNE_ASSOCCHANGED: Windows' own "file types changed" notice, so the New menu picks it up.
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  IfFileExists "$INSTDIR\${MAINBINARYNAME}.exe" 0 +3
    ExecWait '"$INSTDIR\${MAINBINARYNAME}.exe" --quit'
    ExecWait '"$INSTDIR\${MAINBINARYNAME}.exe" --show-icons'
  ; "Start with Windows" entry written by the app.
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${PRODUCTNAME}"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" "${PRODUCTNAME}"
  ; "Yeni ▸ Grup": remove exactly what the installer added.
  DeleteRegKey HKCU "Software\Classes\.fegroup"
  DeleteRegKey HKCU "Software\Classes\FolderExplorer.Group"
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, p 0, p 0)'
!macroend

!macro NSIS_HOOK_POSTUNINSTALL
!macroend
