//! The one change Folder Explorer makes to Windows' own shell: the standard per-user "Yeni ▸ Grup"
//! entry of the New menu (two keys under HKCU\Software\Classes). Controlled by the setting
//! `behavior.newMenuEntry` (Ayarlar ▸ Davranış); turning it off removes exactly those keys.
//! Explorer's New-menu cache is never touched.

use windows::core::{w, HSTRING, PCWSTR};
use windows::Win32::Foundation::ERROR_SUCCESS;
use windows::Win32::System::Registry::{
    RegCloseKey, RegCreateKeyExW, RegDeleteTreeW, RegGetValueW, RegSetValueExW, HKEY, HKEY_CURRENT_USER,
    KEY_WRITE, REG_OPTION_NON_VOLATILE, REG_SZ, RRF_RT_REG_SZ,
};
use windows::Win32::UI::Shell::{SHChangeNotify, SHCNE_ASSOCCHANGED, SHCNF_IDLIST};

const EXT_KEY: PCWSTR = w!("Software\\Classes\\.fegroup");
const SHELLNEW_KEY: PCWSTR = w!("Software\\Classes\\.fegroup\\ShellNew");
const PROGID_KEY: PCWSTR = w!("Software\\Classes\\FolderExplorer.Group");
const ICON_KEY: PCWSTR = w!("Software\\Classes\\FolderExplorer.Group\\DefaultIcon");

fn wide_bytes(s: &str) -> Vec<u8> {
    s.encode_utf16().chain(std::iter::once(0)).flat_map(|u| u.to_le_bytes()).collect()
}

unsafe fn set_str(key: PCWSTR, name: PCWSTR, value: &str) -> Result<(), String> {
    let mut h = HKEY::default();
    let rc = RegCreateKeyExW(HKEY_CURRENT_USER, key, None, PCWSTR::null(), REG_OPTION_NON_VOLATILE, KEY_WRITE, None, &mut h, None);
    if rc != ERROR_SUCCESS {
        return Err(format!("kayıt anahtarı oluşturulamadı ({})", rc.0));
    }
    let rc = RegSetValueExW(h, name, None, REG_SZ, Some(&wide_bytes(value)));
    let _ = RegCloseKey(h);
    if rc != ERROR_SUCCESS {
        return Err(format!("kayıt değeri yazılamadı ({})", rc.0));
    }
    Ok(())
}

unsafe fn get_str(key: PCWSTR, name: PCWSTR) -> Option<String> {
    let mut size = 0u32;
    if RegGetValueW(HKEY_CURRENT_USER, key, name, RRF_RT_REG_SZ, None, None, Some(&mut size)) != ERROR_SUCCESS || size < 2 {
        return None;
    }
    let mut buf = vec![0u16; (size as usize + 1) / 2];
    let rc = RegGetValueW(HKEY_CURRENT_USER, key, name, RRF_RT_REG_SZ, None, Some(buf.as_mut_ptr() as *mut _), Some(&mut size));
    (rc == ERROR_SUCCESS).then(|| String::from_utf16_lossy(&buf).trim_end_matches('\0').to_string())
}

fn notify() {
    // SHCNE_ASSOCCHANGED: Windows' own "file types changed" notice, so the New menu is rebuilt.
    unsafe { SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, None, None) };
}

/// Make the registry match `enabled`. Does nothing (and sends no notice) when it already does.
pub fn sync(enabled: bool) {
    let exe = std::env::current_exe().map(|p| p.to_string_lossy().into_owned()).unwrap_or_default();
    if exe.is_empty() {
        return;
    }
    let command = format!("\"{exe}\" --new-group");
    unsafe {
        let current = get_str(SHELLNEW_KEY, w!("Command"));
        if enabled {
            if current.as_deref() == Some(command.as_str()) {
                return;
            }
            let icon = format!("{exe},0");
            let written = set_str(EXT_KEY, PCWSTR::null(), "FolderExplorer.Group")
                .and(set_str(SHELLNEW_KEY, w!("Command"), &command))
                .and(set_str(SHELLNEW_KEY, w!("MenuText"), "Grup"))
                .and(set_str(SHELLNEW_KEY, w!("IconPath"), &icon))
                .and(set_str(PROGID_KEY, PCWSTR::null(), "Grup"))
                .and(set_str(ICON_KEY, PCWSTR::null(), &icon));
            match written {
                Ok(()) => notify(),
                Err(e) => crate::dlog!("Yeni ▸ Grup kaydı yazılamadı: {e}"),
            }
        } else if current.is_some() || get_str(EXT_KEY, PCWSTR::null()).is_some() {
            let _ = RegDeleteTreeW(HKEY_CURRENT_USER, &HSTRING::from("Software\\Classes\\.fegroup"));
            let _ = RegDeleteTreeW(HKEY_CURRENT_USER, &HSTRING::from("Software\\Classes\\FolderExplorer.Group"));
            notify();
        }
    }
}
