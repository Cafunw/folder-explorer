// Prevents an extra console window on Windows in release.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if let Some(i) = args.iter().position(|a| a == "--watchdog") {
        folder_explorer_lib::watchdog(args.get(i + 1));
        return;
    }
    // Used by the installer/uninstaller: bring the Windows desktop icons back, no UI.
    if args.iter().any(|a| a == "--quit") {
        folder_explorer_lib::quit_running();
        return;
    }
    // "Yeni ▸ Grup": hand over to the running desktop (if it is not running, just start it).
    if args.iter().any(|a| a == "--new-group") && folder_explorer_lib::new_group() {
        return;
    }
    if args.iter().any(|a| a == "--show-icons") {
        folder_explorer_lib::show_icons();
        return;
    }
    if args.iter().any(|a| a == "--selftest" || a == "--fileops-test" || a == "--ztest" || a == "--restore" || a == "--store-test" || a == "--newmenu-dump" || a == "--newmenu-test" || a == "--item-select-test") {
        folder_explorer_lib::selftest(&args);
        return;
    }
    folder_explorer_lib::run()
}
